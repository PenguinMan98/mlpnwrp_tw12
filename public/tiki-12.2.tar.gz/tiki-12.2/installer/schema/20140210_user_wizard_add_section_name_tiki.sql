UPDATE tiki_menu_options SET section = 'feature_wizard_user' WHERE name = 'User Wizard';
