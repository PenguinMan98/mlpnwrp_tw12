ALTER TABLE `tiki_tracker_items` ADD COLUMN `createdBy` varchar(200) default NULL;
ALTER TABLE `tiki_tracker_items` ADD COLUMN `lastModifBy` varchar(200) default NULL;
