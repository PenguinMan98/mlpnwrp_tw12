ALTER TABLE `tiki_articles` ADD `ispublished` char(1) NOT NULL DEFAULT 'y';
