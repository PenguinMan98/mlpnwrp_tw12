#sylvieg
INSERT INTO users_permissions (`permName`, `permDesc`, level, type) VALUES ('tiki_p_export_tracker', 'Can export tracker items', 'registered', 'trackers');

