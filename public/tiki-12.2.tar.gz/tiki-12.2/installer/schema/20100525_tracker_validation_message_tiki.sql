#2010-05-25 nkoth
ALTER TABLE tiki_tracker_fields ADD COLUMN `validationMessage` varchar(255) default '';
