alter table `tiki_page_lists` convert to charset default;
alter table `tiki_page_list_types` convert to charset default;
