UPDATE `tiki_preferences` SET `name` =  'ajax_autosave' WHERE  `tiki_preferences`.`name` =  'feature_ajax_autosave';
