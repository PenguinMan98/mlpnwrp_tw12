delete from `tiki_actionlog` where `objectType`='trackeritem' and `action`='Modified';
