ALTER TABLE `tiki_payment_requests` ADD COLUMN `userId` int(8);
ALTER TABLE `tiki_payment_received` ADD COLUMN `userId` int(8);
