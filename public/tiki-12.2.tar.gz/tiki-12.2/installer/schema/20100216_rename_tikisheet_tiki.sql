-- 2010-02-16 jonnybradley - Removing upstream from Mozilla
UPDATE `tiki_menu_options` SET `name` = 'Spreadsheets' WHERE `name` = 'TikiSheet';
