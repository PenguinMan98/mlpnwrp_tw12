INSERT INTO `tiki_sefurl_regex_out` (`left`, `right`, `type`, `feature`, `order`)
	VALUES ('tiki-view_forum_thread.php\\?comments_parentId=(\\d+)', 'forumthread$1', 'forumthread', 'feature_forums', '0');
