UPDATE `tiki_modules` SET `params` = 'nobox=y' WHERE `name` = 'logo' and `params` = 'nobox=y&style=float%3Aleft%3Bmargin%3A0+30px%3B';
UPDATE `tiki_modules` SET `params` = 'mode=popup&nobox=y' WHERE `name` = 'login_box' and `params` = 'mode=header&nobox=y&style=position%3Aabsolute%3Bright%3A30px%3Btop%3A5px%3B';
UPDATE `tiki_modules` SET `params` = 'nobox=y' WHERE `name` = 'search' and `params` = 'nobox=y&style=float%3Aright%3Bclear%3Aright%3B';
UPDATE `tiki_modules` SET `params` = 'nobox=y' WHERE `name` = 'quickadmin' and `params` = 'nobox=y&style=position%3A+absolute%3B+right%3A+200px%3B';

