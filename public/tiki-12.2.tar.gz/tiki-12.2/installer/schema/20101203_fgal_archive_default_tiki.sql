ALTER TABLE `tiki_file_galleries` CHANGE `archives` `archives` INT( 4 ) NULL DEFAULT  '0';
