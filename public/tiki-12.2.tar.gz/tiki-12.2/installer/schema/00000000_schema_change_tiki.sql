#2008-09-24 lphuberdeau
ALTER TABLE tiki_schema MODIFY patch_name VARCHAR(100) ;
