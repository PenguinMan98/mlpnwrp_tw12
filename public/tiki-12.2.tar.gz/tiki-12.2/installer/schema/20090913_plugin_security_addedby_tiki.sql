#ricks99
ALTER TABLE tiki_plugin_security ADD added_by VARCHAR( 200 ) NULL AFTER status;