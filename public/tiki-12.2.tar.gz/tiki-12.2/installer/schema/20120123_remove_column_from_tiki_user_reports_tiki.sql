ALTER TABLE `tiki_user_reports` DROP COLUMN `time_to_send`;
