ALTER TABLE tiki_categories MODIFY name VARCHAR(200) default NULL;
