ALTER TABLE `tiki_tracker_item_field_logs` DROP INDEX `fieldId`, ADD INDEX `fieldId` (`fieldId`);
