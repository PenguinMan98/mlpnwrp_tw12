DELETE FROM `tiki_menu_options` WHERE `section` = 'feature_mobile';
DELETE FROM `tiki_sefurl_regex_out` WHERE `feature` = 'feature_mobile';
