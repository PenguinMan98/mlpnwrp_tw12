#sylvieg
update  tiki_menu_options set url='tiki-admin.php'  WHERE url='' and position ='1050' and name='Admin';
