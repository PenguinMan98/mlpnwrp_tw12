#sylvieg
update tiki_user_assigned_modules set name='Menuapplication' where name='application_menu';
update tiki_modules set name='Menuapplication' where name='application_menu';