-- 2010-02-16 jonnybradley - Removing upstream from Mozilla
DELETE FROM `users_permissions` WHERE `permName` = 'tiki_p_upload_screencast';
