ALTER IGNORE TABLE `tiki_language` MODIFY `tran` text;
ALTER IGNORE TABLE `tiki_language` MODIFY `source` text;
