UPDATE users_permissions SET feature_check = 'feature_wiki' WHERE `permName` = 'tiki_p_use_as_template';
