# Jyhem
ALTER TABLE `tiki_blog_posts` ADD `wysiwyg` VARCHAR( 1 ) DEFAULT NULL;

