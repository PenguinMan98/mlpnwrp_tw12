DROP TABLE IF EXISTS `tiki_events`;
