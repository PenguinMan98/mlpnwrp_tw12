#jonnyb
ALTER TABLE  `tiki_file_galleries` ADD `wiki_syntax` VARCHAR( 200 ) NULL;
