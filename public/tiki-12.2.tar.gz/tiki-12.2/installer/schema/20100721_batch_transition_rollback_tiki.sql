ALTER TABLE `tiki_transitions` DROP COLUMN `batch`;
ALTER TABLE `tiki_transitions` DROP COLUMN `objectId`;
