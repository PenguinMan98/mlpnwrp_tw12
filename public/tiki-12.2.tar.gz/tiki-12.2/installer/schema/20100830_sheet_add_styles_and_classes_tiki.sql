ALTER TABLE `tiki_sheet_values` ADD `style` VARCHAR( 255 ) DEFAULT '';
ALTER TABLE `tiki_sheet_values` ADD `class` VARCHAR( 255 ) DEFAULT '';
