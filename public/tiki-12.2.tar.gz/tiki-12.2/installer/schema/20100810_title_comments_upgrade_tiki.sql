# 2010-08-10 Jyhem

INSERT IGNORE INTO tiki_preferences (`name`,`value`) VALUES ('comments_notitle','n');
