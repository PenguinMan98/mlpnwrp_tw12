UPDATE `tiki_preferences` SET `name` = 'blogs_feature_copyrights' WHERE `name` = 'blogues_feature_copyrights';
