
#2008-11-20 aproulx
ALTER TABLE tiki_galleries ADD COLUMN showcategories CHAR(1) NOT NULL DEFAULT 'n';