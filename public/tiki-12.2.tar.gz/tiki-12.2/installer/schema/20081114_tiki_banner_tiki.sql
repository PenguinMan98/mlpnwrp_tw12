#gillesm
ALTER TABLE tiki_banners ADD `maxClicks` int(8) default NULL;