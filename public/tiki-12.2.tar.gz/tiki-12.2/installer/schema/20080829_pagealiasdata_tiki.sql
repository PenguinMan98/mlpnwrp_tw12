
#2008-08-29 lphuberdeau
INSERT INTO tiki_semantic_tokens (token, label) VALUES('alias', 'Page Alias');

