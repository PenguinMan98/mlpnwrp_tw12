ALTER TABLE `tiki_newsletter_groups` ADD COLUMN `include_groups` CHAR(1) DEFAULT 'y';
