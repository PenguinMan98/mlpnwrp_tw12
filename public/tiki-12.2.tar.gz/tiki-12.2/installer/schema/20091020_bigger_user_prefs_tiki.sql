ALTER TABLE `tiki_user_preferences` CHANGE `value` `value` TEXT;
