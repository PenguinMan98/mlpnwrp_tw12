-- lphuberdeau
ALTER TABLE `users_permissions` DROP COLUMN `permDesc`;
ALTER TABLE `users_permissions` DROP COLUMN `type`;
ALTER TABLE `users_permissions` DROP COLUMN `admin`;
ALTER TABLE `users_permissions` DROP COLUMN `feature_check`;
