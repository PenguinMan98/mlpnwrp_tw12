DELETE FROM tiki_preferences WHERE name='users_prefs_language';
