ALTER TABLE `tiki_file_galleries` ADD COLUMN `show_slideshow` char(1) default NULL;
ALTER TABLE `tiki_file_galleries` ADD COLUMN `default_view` varchar(20) default NULL;
