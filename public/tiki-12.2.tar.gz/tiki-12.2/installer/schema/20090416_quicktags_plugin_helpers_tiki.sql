UPDATE  `tiki_quicktags` SET  `taginsert` =  'popup_plugin_form("quote")' WHERE  `tiki_quicktags`.`taglabel` =  'quote';
UPDATE  `tiki_quicktags` SET  `taginsert` =  'popup_plugin_form("code")' WHERE  `tiki_quicktags`.`taglabel` =  'code';
UPDATE  `tiki_quicktags` SET  `taginsert` =  'popup_plugin_form("flash")' WHERE  `tiki_quicktags`.`taglabel` =  'flash';
UPDATE  `tiki_quicktags` SET  `taginsert` =  'popup_plugin_form("img")' WHERE  `tiki_quicktags`.`taglabel` =  'image';
