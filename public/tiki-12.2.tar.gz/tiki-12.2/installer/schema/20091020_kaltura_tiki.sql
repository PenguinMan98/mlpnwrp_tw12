UPDATE tiki_menu_options set url = 'tiki-kaltura_upload.php' where name = 'Upload Media' and section = 'feature_kaltura';
