ALTER TABLE `tiki_article_types` DROP COLUMN `show_lang`;
