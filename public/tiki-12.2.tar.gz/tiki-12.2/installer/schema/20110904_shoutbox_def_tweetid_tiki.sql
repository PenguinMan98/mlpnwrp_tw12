ALTER TABLE tiki_shoutbox modify tweetId BIGINT(20) UNSIGNED NOT NULL default 0;
