# 2009-08-06 lphuberdeau
INSERT INTO users_permissions (`permName`, `permDesc`, level, type) VALUES ('tiki_p_group_view', 'Can view the group', 'basic', 'group');
INSERT INTO users_permissions (`permName`, `permDesc`, level, type) VALUES ('tiki_p_group_view_members', 'Can view the group members', 'basic', 'group');
INSERT INTO users_permissions (`permName`, `permDesc`, level, type) VALUES ('tiki_p_group_add_member', 'Can add group members', 'admin', 'group');
INSERT INTO users_permissions (`permName`, `permDesc`, level, type) VALUES ('tiki_p_group_remove_member', 'Can remove group members', 'admin', 'group');
INSERT INTO users_permissions (`permName`, `permDesc`, level, type) VALUES ('tiki_p_group_join', 'Can join or leave the group', 'admin', 'group');
