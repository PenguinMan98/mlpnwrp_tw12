ALTER TABLE `tiki_blog_posts` CHANGE `priv` `priv` varchar(1) DEFAULT 'n'; # Forgotten in r33946
