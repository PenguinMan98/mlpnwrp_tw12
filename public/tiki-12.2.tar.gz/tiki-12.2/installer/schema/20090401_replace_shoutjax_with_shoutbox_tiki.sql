# jonnyb
# shoutjax replacing shoutbox module
UPDATE `tiki_modules` SET `name` = 'shoutbox' WHERE `tiki_modules`.`name` = 'shoutjax';
