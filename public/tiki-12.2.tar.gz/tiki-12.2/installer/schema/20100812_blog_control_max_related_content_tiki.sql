ALTER TABLE `tiki_blogs` ADD COLUMN `related_max` int(4) DEFAULT 5;
