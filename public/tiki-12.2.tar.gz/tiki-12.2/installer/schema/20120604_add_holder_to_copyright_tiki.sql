ALTER TABLE `tiki_copyrights` ADD COLUMN `holder` VARCHAR(200) NULL AFTER `authors`;
