ALTER TABLE `tiki_links` DROP COLUMN `reltype`;
