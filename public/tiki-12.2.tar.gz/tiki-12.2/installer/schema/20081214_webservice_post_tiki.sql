
#2008-12-14 lphuberdeau
ALTER TABLE `tiki_webservice` ADD `body` TEXT NULL AFTER `url` ;

