#GMartin
ALTER TABLE `tiki_blog_posts` ADD `hits` BIGINT DEFAULT 0 AFTER `user` ;
