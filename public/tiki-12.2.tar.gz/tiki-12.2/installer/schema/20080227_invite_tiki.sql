#sylvieg
INSERT INTO users_permissions (`permName`, `permDesc`, level, type) VALUES ('tiki_p_invite', 'Can invite user in groups', 'editors', 'tiki');