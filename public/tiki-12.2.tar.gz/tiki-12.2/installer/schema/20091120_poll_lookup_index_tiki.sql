ALTER TABLE tiki_polls ADD INDEX tiki_poll_lookup ( active , title );
