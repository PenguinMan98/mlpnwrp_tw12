# Jyhem
ALTER TABLE `tiki_file_galleries` ADD `image_max_size_x` INT( 8 ) NOT NULL DEFAULT '0';
ALTER TABLE `tiki_file_galleries` ADD `image_max_size_y` INT( 8 ) NOT NULL DEFAULT '0';
