INSERT INTO `tiki_preferences` (`name`, `value`) VALUES ('default_kaltura_editor', 'kae');
