ALTER TABLE `tiki_freetags` MODIFY `tag` varchar(128)  NOT NULL default '';
ALTER TABLE `tiki_freetags` MODIFY `raw_tag` varchar(150) NOT NULL default '';
