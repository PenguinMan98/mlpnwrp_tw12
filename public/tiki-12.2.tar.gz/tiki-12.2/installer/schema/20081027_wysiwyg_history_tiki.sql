
#2008-10-27 lphuberdeau
ALTER TABLE tiki_history ADD COLUMN is_html TINYINT(1) NOT NULL DEFAULT 0;

