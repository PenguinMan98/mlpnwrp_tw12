ALTER TABLE `tiki_pages` ADD COLUMN `keywords` TEXT;
