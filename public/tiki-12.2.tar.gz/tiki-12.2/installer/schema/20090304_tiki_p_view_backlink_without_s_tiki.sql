#sylvieg
update users_permissions set `permName`='tiki_p_view_backlink' where `permName`='tiki_p_view_backlinks';
update users_objectpermissions set `permName`='tiki_p_view_backlink' where `permName`='tiki_p_view_backlinks';